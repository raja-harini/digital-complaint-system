package com.example.digcompsys;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DigcompsysApplication {

	public static void main(String[] args) {
		SpringApplication.run(DigcompsysApplication.class, args);
	}

}
